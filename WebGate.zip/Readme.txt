Installation:
--------------

1) Unzip the files into the www directory that you wish to protect.

2) Edit the password.txt and url.txt files to reflect your site's needs

3) Upload