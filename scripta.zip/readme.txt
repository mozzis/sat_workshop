Copyright		: Palace Multimedia
Catagory		: ANTHILL Software 
Product			: Scripter 1.1 
Status			: FREEWARE
Last Update		: 12.8.1998

________________________________________________________________
ANTHILL Scripter 1.1		
__________________________
			  |
                      
ANTHILL Scripter 1.1		
Javascript Editor


1.   Extract the zip contents into a directory on your hard drive.


2.   Locate scripter.htm in Netscape or Internet Explorer 3 & above
     and bookmark.


########################
Please send Bug Reports 

palace@apo.com.au

########################


			   COPYRIGHT NOTICE

This licence grants the right to store the ANTHILL Scripter 1.1
on any personal computer or LAN free of charge. 

________________________________
Palace Multimedia

Email: palace@apo.com.au
Web:   http://www.apo.com.au